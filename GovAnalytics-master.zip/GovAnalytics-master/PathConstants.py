class PathConstants:
    BILL_ROOT = "D:\\CongressData4"
    LEGISLATOR_ROOT = "D:\\LegislatorData"

    BILL_FAILURE = "D:\\Gov_Process_Failures"
