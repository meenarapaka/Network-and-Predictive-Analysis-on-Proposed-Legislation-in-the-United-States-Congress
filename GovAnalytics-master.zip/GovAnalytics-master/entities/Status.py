class Status:

    def __init__(self, state, date):
        self.state = state
        self.date = date
