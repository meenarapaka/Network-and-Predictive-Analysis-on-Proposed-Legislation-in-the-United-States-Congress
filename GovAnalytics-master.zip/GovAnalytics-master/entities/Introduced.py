class Introduced:

    def __init__(self, date):
        self.date = date
